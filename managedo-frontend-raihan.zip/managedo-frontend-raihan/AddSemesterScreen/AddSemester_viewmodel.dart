import '../viewmodel.dart';

class AddSemesterViewModel extends Viewmodel {}
